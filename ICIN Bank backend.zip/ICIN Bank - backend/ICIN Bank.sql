use icin_bank;

select * from accounts;

select * from transactions;

select * from users;

select * from cheque;



